//
//  PcScreenTimerApp.swift
//  PcScreenTimer
//
//  Created by Antonio De Luca on 04/03/23.
//

import SwiftUI

@main
struct PcScreenTimerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView2()
        }
    }
}
